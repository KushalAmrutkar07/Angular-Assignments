import { Component } from '@angular/core';

@Component({
  selector: 'app-wrongchoice',
  templateUrl: './wrongchoice.component.html',
  styleUrls: ['./wrongchoice.component.css']
})
export class WrongchoiceComponent {

}
