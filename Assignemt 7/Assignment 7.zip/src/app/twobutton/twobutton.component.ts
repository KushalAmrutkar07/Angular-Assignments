import { Component } from '@angular/core';

@Component({
  selector: 'app-twobutton',
  templateUrl: './twobutton.component.html',
  styleUrls: ['./twobutton.component.css']
})
export class TwobuttonComponent 
{
  public Data = "______";

  public MyAction()
  {
    this.Data = "Marvellous Infosystem...";
  }

}
