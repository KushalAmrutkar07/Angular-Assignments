import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TwobuttonComponent } from './twobutton.component';

describe('TwobuttonComponent', () => {
  let component: TwobuttonComponent;
  let fixture: ComponentFixture<TwobuttonComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ TwobuttonComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(TwobuttonComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
