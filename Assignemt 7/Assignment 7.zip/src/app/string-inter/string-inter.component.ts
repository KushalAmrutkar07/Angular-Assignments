import { Component } from '@angular/core';

@Component({
  selector: 'app-string-inter',
  templateUrl: './string-inter.component.html',
  styleUrls: ['./string-inter.component.css']
})
export class StringInterComponent 
{
  public Display() :string
  {
    return "Marvellous Infosystems"
  }

}
